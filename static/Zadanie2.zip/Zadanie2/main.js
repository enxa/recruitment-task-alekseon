const fs = require('fs')

let ilePapieruPotrzeba = async () => {
  console.time('czas')
  let result = 0

  // tutaj obliczenie
  let boxesTxt = await fs.readFileSync('boxes.txt', 'utf8')
    
  let boxes = []

  await boxesTxt.split(/\r?\n/).forEach(box => boxes.push(box.split('x')))
  
  await boxes.forEach(box => {
    let boxSides = [2*(box[0]*box[1]), 2*(box[1]*box[2]), 2*(box[2]*box[0])]
    let minBoxSide = Math.min(...boxSides)
    result += boxSides[0] + boxSides[1] + boxSides[2] + minBoxSide
  })
  
  console.timeEnd('czas')
  return result
}

ilePapieruPotrzeba()
.then(res => console.log(res))
.catch(err => console.error(err))
