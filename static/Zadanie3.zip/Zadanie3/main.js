const fs = require('fs')

let wIluDomachBylMikolaj = async () => {
    console.time('czas');
    let result = [];

    // tutaj obliczenie
    let directionsTxt = await fs.readFileSync('navigation.txt', 'utf8')

    let directions = directionsTxt.split('')
    
    let coords = []
    
    let currentCoords = {
      x: 0,
      y: 0
    }

    let nextCoords = {}
    
    await directions.forEach(direction => {
      nextCoords = {...currentCoords}
      if (direction === '^') nextCoords.y += 1
      if (direction === 'v') nextCoords.y -= 1
      if (direction === '>') nextCoords.x += 1
      if (direction === '<') nextCoords.x -= 1
      currentCoords = nextCoords
      coords.push(currentCoords)
    })
    
    let set = new Set
    result = await coords.filter(coord => !set.has(JSON.stringify(coord)) && set.add(JSON.stringify(coord)))

    console.timeEnd('czas')
    return result.length
}

wIluDomachBylMikolaj()
.then(res => console.log(res))
.catch(err => console.error(err))
