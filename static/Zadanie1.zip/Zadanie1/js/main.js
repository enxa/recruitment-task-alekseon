(() => {
    let runHeroSlider = () => {
        let i = 0
        let duration = 5000;
        let heroSlidesDOM = Array.from(document.querySelector('.hero-slider').children)
        heroSlidesDOM.forEach(slide => slide.style.transition = `${duration/10000}s all`)
        
        let slideShow = () => {
            heroSlidesDOM.forEach(slide => slide.style.opacity = 0)
            heroSlidesDOM[i].style.opacity = 1
            ++i >= heroSlidesDOM.length ? i = 0 : i
        }

        setInterval(() => slideShow(), duration)
    }

    let toggleNotifications = () => {
        let notificationsLinkDOM = document.querySelector('.notifications-link')
        let notificationsDOM = document.querySelector('.notifications')

        let notificationShow = false

        notificationsLinkDOM.addEventListener('click', e => {
            e.preventDefault()
            notificationShow = !notificationShow
           
            if (notificationShow) {
                notificationsLinkDOM.style.backgroundColor = '#fff'
                notificationsDOM.style.opacity = 1;
                notificationsDOM.style.visibility = 'visible';
            }
            if (!notificationShow) {
                notificationsLinkDOM.style.backgroundColor = 'transparent'
                notificationsDOM.style.opacity = 0;
                notificationsDOM.style.visibility = 'hidden';
            }
        })
    }

    window.onload = () => {
        runHeroSlider()
        toggleNotifications()
    }
})()